var class_pagerank =
[
    [ "Pagerank", "class_pagerank.html#a0249230f1b08b4112c58e6df3824f90b", null ],
    [ "Build", "class_pagerank.html#a43e8765518f302660eafed4d65cffdcd", null ],
    [ "BuildFromFile", "class_pagerank.html#a3fa940b459254251eca931b4a141abdf", null ],
    [ "GetMax", "class_pagerank.html#a8dcfcbfd536455a01ea21a9155100f2a", null ],
    [ "GetSeed", "class_pagerank.html#abcc3d9efcec52bd21e29f6614940db9a", null ],
    [ "GetSeedList", "class_pagerank.html#a64f84bebdeb14e18af9dfacf582c49d5", null ]
];