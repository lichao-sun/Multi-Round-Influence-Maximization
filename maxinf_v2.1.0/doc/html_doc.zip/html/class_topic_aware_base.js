var class_topic_aware_base =
[
    [ "TASeedsMap", "class_topic_aware_base.html#a291bdb3e41b6b3dd9db9788ad6eafd29", null ]
];