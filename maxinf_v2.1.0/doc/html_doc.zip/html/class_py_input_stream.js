var class_py_input_stream =
[
    [ "~PyInputStream", "class_py_input_stream.html#aeeae563730f196c255379ef8348348d1", null ],
    [ "ptr", "class_py_input_stream.html#aea67527b99180c4ec60b75348042aa2e", null ]
];