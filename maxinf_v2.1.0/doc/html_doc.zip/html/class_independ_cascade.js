var class_independ_cascade =
[
    [ "Build", "class_independ_cascade.html#a61701f7a3b308b7909f308395bcf3e4b", null ],
    [ "Run", "class_independ_cascade.html#acda7a31684fc301ca8e60b1885350c0d", null ],
    [ "ratio", "class_independ_cascade.html#a38a249ea439090d365027db262c8a2c8", null ]
];