var hierarchy =
[
    [ "_EdgeDownwardAdapter", "class___edge_downward_adapter.html", null ],
    [ "BaseEdge", "class_base_edge.html", [
      [ "Edge", "class_edge.html", [
        [ "ContEdge", "class_cont_edge.html", null ]
      ] ]
    ] ],
    [ "CountComparator", "struct_count_comparator.html", null ],
    [ "Degree", "class_degree.html", null ],
    [ "DegreeDiscount_IC", "class_degree_discount___i_c.html", null ],
    [ "EdgeComparatorT< TEdge >", "class_edge_comparator_t.html", null ],
    [ "EdgeSorterT< TEdge >", "class_edge_sorter_t.html", null ],
    [ "false_t", "structfalse__t.html", null ],
    [ "GraphFactoryT< TEdge, TGraph, TEdgeSorter >", "class_graph_factory_t.html", null ],
    [ "GraphStatisticsT< TGraph >", "class_graph_statistics_t.html", null ],
    [ "Greedy", "class_greedy.html", [
      [ "CGreedy", "class_c_greedy.html", null ]
    ] ],
    [ "GreedyOnline", "class_greedy_online.html", null ],
    [ "ICascade", "class_i_cascade.html", [
      [ "CascadeT< TGraph >", "class_cascade_t.html", null ],
      [ "CascadeT< ContGraph >", "class_cascade_t.html", [
        [ "ContGeneralCascade", "class_cont_general_cascade.html", null ]
      ] ],
      [ "CascadeT< Graph >", "class_cascade_t.html", [
        [ "GeneralCascadeT< TGraph >", "class_general_cascade_t.html", null ],
        [ "IndependCascade", "class_independ_cascade.html", null ]
      ] ],
      [ "SP1M_gc", "class_s_p1_m__gc.html", null ],
      [ "SPM_gc", "class_s_p_m__gc.html", null ]
    ] ],
    [ "IGraph", "class_i_graph.html", [
      [ "GraphT< TEdge >", "class_graph_t.html", null ]
    ] ],
    [ "MIA", "class_m_i_a.html", null ],
    [ "MICommandLine", "class_m_i_command_line.html", null ],
    [ "MICommon", "class_m_i_common.html", null ],
    [ "MINode", "struct_m_i_node.html", null ],
    [ "MIRandom", "class_m_i_random.html", null ],
    [ "MIS", "class_m_i_s.html", null ],
    [ "Pagerank", "class_pagerank.html", null ],
    [ "PCTimerT< TKey >", "class_p_c_timer_t.html", null ],
    [ "PMIA", "class_p_m_i_a.html", null ],
    [ "ProbConverter", "class_prob_converter.html", null ],
    [ "PyHelper", "class_py_helper.html", null ],
    [ "PyInputStream", "class_py_input_stream.html", null ],
    [ "PyOutputStream", "class_py_output_stream.html", null ],
    [ "RandomPick", "class_random_pick.html", null ],
    [ "ReverseGCascadeT< TGraph >", "class_reverse_g_cascade_t.html", null ],
    [ "RRInflBase", "class_r_r_infl_base.html", [
      [ "RRInfl", "class_r_r_infl.html", null ],
      [ "TimPlus", "class_tim_plus.html", [
        [ "IMM", "class_i_m_m.html", null ]
      ] ]
    ] ],
    [ "runtime_error", null, [
      [ "NullPointerException", "class_null_pointer_exception.html", null ]
    ] ],
    [ "Simu", "class_simu.html", null ],
    [ "TASeeds", "struct_t_a_seeds.html", null ],
    [ "TimeItem", "class_time_item.html", null ],
    [ "TopicAwareBase", "class_topic_aware_base.html", null ],
    [ "TopSelection", "class_top_selection.html", null ],
    [ "true_t", "structtrue__t.html", null ],
    [ "WeightedDegree", "class_weighted_degree.html", null ]
];