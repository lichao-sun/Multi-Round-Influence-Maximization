var class_greedy =
[
    [ "Greedy", "class_greedy.html#a916c0ab051f780c4d3ccec06f44bbf6c", null ],
    [ "Build", "class_greedy.html#af664bd0eb89801b29299c2575523b428", null ],
    [ "BuildFromFile", "class_greedy.html#af50d7ba662181ca68e5361b2ae6f8b02", null ],
    [ "BuildRanking", "class_greedy.html#ab1e17c25c41ee023a2c98ff01fc6e9f4", null ],
    [ "GetSeed", "class_greedy.html#a6ffbf75a3ab66e66ac05a8aababa3545", null ],
    [ "GetSeedList", "class_greedy.html#ad3ba4bb9e22501b1017c8793e8629eec", null ],
    [ "d", "class_greedy.html#a64cb651f02e3b6ed10f2714e7fa7bfe8", null ],
    [ "file", "class_greedy.html#a4c916a38ef9a689be5e5827783560040", null ],
    [ "list", "class_greedy.html#a0517f163a334ef64cc153ba0c757e8a9", null ],
    [ "n", "class_greedy.html#adb9ec8a9367c9fd820725b9190a8cd1f", null ],
    [ "top", "class_greedy.html#a9683998a3eb078489d923448fde89570", null ]
];