var class_null_pointer_exception =
[
    [ "NullPointerException", "class_null_pointer_exception.html#a58309a2f545d926ab76586066e91e1a5", null ]
];