var limit_8h =
[
    [ "EPS", "limit_8h.html#a6ebf6899d6c1c8b7b9d09be872c05aae", null ],
    [ "MAX_K", "limit_8h.html#ae183b92efbb93c3a7b3647a10b9e5f98", null ],
    [ "MAX_NODE", "limit_8h.html#a456b0bf8fc3799e25c3ee34d62c68824", null ],
    [ "NUM_ITER", "limit_8h.html#a54141d8b6f8555b5e7998203c65e81da", null ],
    [ "SET_SIZE", "limit_8h.html#aa6e05f1d2f795fe52b3a112b050db5ea", null ],
    [ "STR_LEN", "limit_8h.html#af5b27449abdfc22a937250696492e03f", null ]
];