var class_c_greedy =
[
    [ "CGreedy", "class_c_greedy.html#a7765b8e7e74bce49e17445bf6aac23ef", null ],
    [ "BuildWithCandidates", "class_c_greedy.html#aee2f5e0ed1b4718aa906b7b5a8fcb0e9", null ]
];