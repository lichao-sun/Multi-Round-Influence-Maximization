var class_i_graph =
[
    [ "self_type", "class_i_graph.html#a380da1b8dff10fdc243c46fd1e9adf5f", null ],
    [ "GetM", "class_i_graph.html#affe47b4ba9bc75699b991d14b3e3a922", null ],
    [ "GetN", "class_i_graph.html#a10297727bca653e5608447f3a05c825c", null ]
];