var class_tim_plus =
[
    [ "TimPlus", "class_tim_plus.html#a1d6b98584664c1121d5b9a80fbc2d82b", null ],
    [ "Build", "class_tim_plus.html#a1b42a5dab91f476fc75e78d24117eace", null ],
    [ "EpsPrime", "class_tim_plus.html#add14ec7c89e7be243c5670492d173a4a", null ],
    [ "LogNChooseK", "class_tim_plus.html#a0f281fcccd212e610ae90ecfc9ed7573", null ],
    [ "RThreshold", "class_tim_plus.html#a0c4c9447dffa805f74dc84dec09dbfa2", null ],
    [ "RThreshold_0", "class_tim_plus.html#a50e9ee23158975197223285d15dc468d", null ],
    [ "StepThreshold", "class_tim_plus.html#a75816e3cc70e55f8d35d55fb6842251c", null ],
    [ "file", "class_tim_plus.html#a31b354093bf7a23c4da47aca1682edb0", null ],
    [ "time_file", "class_tim_plus.html#a78bb72531d266d7c936c783facf70474", null ]
];