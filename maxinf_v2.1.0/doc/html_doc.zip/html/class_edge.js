var class_edge =
[
    [ "Edge", "class_edge.html#ae39469000a1f2ab36174d23d9d727aaf", null ],
    [ "Deserialize", "class_edge.html#af0f01f1ba9c1ab29d77f9c4ec83f3393", null ],
    [ "Serialize", "class_edge.html#a42a0adea24015ce05b720affc81889ba", null ],
    [ "c", "class_edge.html#aff6a293fc09ecc126524b70d07e13d1b", null ],
    [ "w1", "class_edge.html#af7a5924512da00c8e9a06b785aa521b5", null ],
    [ "w2", "class_edge.html#a4b233dc783208b1645e0461f27c5370a", null ]
];