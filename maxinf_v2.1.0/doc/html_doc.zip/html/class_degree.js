var class_degree =
[
    [ "Degree", "class_degree.html#a682448dac9d2292ea0ff765373eac216", null ],
    [ "Build", "class_degree.html#ae68ab60a051e1e26b62741c2e78510fe", null ],
    [ "BuildFromFile", "class_degree.html#a3ee83f8eb7dc2191cf09263c9d2ee045", null ],
    [ "GetSeed", "class_degree.html#ab1e78462c5d5e6ceae93df882b79698b", null ],
    [ "GetSeedList", "class_degree.html#ab869d49a359fbc4038f8d4bba3a78856", null ]
];