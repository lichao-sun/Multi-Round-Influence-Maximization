var class_edge_comparator_t =
[
    [ "edge_type", "class_edge_comparator_t.html#abbaf2e7baff80f4dbb4bf4755d3b0e72", null ],
    [ "compare", "class_edge_comparator_t.html#a94fb3a1d4b1c02419ce4098b9ae41936", null ]
];