var class_m_i_command_line =
[
    [ "BaselineAlg", "class_m_i_command_line.html#ac280987393115fd35b04e2b098bcc70f", null ],
    [ "BuildRanking", "class_m_i_command_line.html#adaefe6c90542a3a100b68dca9dae2aa7", null ],
    [ "ContinousICAlg", "class_m_i_command_line.html#aef1dba6c5e989034579954a18e8fba82", null ],
    [ "GraphStat", "class_m_i_command_line.html#af07e9b592c5e6ec5c8da9f836b733408", null ],
    [ "GreedyAlg", "class_m_i_command_line.html#af5f75e97734030787647e81261a7a902", null ],
    [ "GreedyOnlineAlg", "class_m_i_command_line.html#a63766c2fedbb983b7eb7e84c25a0ca46", null ],
    [ "Help", "class_m_i_command_line.html#a4e774ccb663d54299c08c2abd553ad82", null ],
    [ "Main", "class_m_i_command_line.html#ad7a7f9270f35a19dbdec4990dfcabf6d", null ],
    [ "MIAAlg", "class_m_i_command_line.html#a2a030f919de21d36ee8e07f448fd81eb", null ],
    [ "PMIAAlg", "class_m_i_command_line.html#a478ac940de127d32ce8ead2a15c5a150", null ],
    [ "RRAlg", "class_m_i_command_line.html#a637c72ff1544ef1df99b56eec955888c", null ],
    [ "TestSeedsByGreedy", "class_m_i_command_line.html#a4bc949d6e7f8ef8edec0a2a19a7bee8a", null ],
    [ "TopicAwareCGreedy", "class_m_i_command_line.html#abccd403c0cf7b8303cf505bd7ecb25c1", null ],
    [ "TopicAwareCGreedyFromList", "class_m_i_command_line.html#a8b983b871ad2d78e0851a0272519c9bb", null ],
    [ "TopicAwareMIS", "class_m_i_command_line.html#aa4e66c15261cbc318e1e9a6459a3cc0b", null ],
    [ "TopicAwareTopSelection", "class_m_i_command_line.html#a0f92b23ae7f1df9826be41fe061142ca", null ]
];