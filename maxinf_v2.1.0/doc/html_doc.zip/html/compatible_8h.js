var compatible_8h =
[
    [ "COMPATIBILITY_OS_APPLE", "compatible_8h.html#a8cc60188c5f74723583186b11cb72dc7", null ],
    [ "COMPATIBILITY_OS_LINUX", "compatible_8h.html#a0fd2f938799f63b08763d7a1f72fbbb5", null ],
    [ "COMPATIBILITY_OS_POSIX", "compatible_8h.html#a1454250159fd0c891a3aed218c0878f0", null ],
    [ "COMPATIBILITY_OS_UNIX", "compatible_8h.html#a9c1da44cfe1a2ffe291bd84cee71a1ce", null ],
    [ "COMPATIBILITY_OS_UNKNOWN", "compatible_8h.html#a1d49564a61d172e655385dfef28658d4", null ],
    [ "COMPATIBILITY_OS_WIN", "compatible_8h.html#af954c6bc27a9ac203d53169c0f808d15", null ],
    [ "COMPATIBILITY_THIS_OS", "compatible_8h.html#ab089139b58f74e40f99a9e5b7a966802", null ],
    [ "COMPATIBILITY_THIS_OS_STR", "compatible_8h.html#a66f924d882fa3d559ee5c3be64e84863", null ],
    [ "fopen_s", "compatible_8h.html#a68aa08b41214e531d230855fbc807d75", null ],
    [ "fscanf_s", "compatible_8h.html#a0a33c9047aaa39206cb522b2b9900bbb", null ],
    [ "log2", "compatible_8h.html#a18af743c2cec4baeee9ffb27999ddaad", null ],
    [ "MI_IS_OMP_USED", "compatible_8h.html#aaa7338e2e6200019877664bf43cbcb4e", null ],
    [ "scanf_s", "compatible_8h.html#a4435ae4ec4f90d537406f802968b254c", null ],
    [ "sprintf_s", "compatible_8h.html#a6b6019110450b61a0b4acc55d7d336ca", null ],
    [ "sscanf_s", "compatible_8h.html#a6730fd34a693bf06bb129ee0166c66f6", null ],
    [ "USE_NEW_FOPEN_S", "compatible_8h.html#aeef76583b5f1f427735e4320838b1c3f", null ],
    [ "USE_NEW_FSCANF_S", "compatible_8h.html#a90dd1fcfe2cee5eb0812c167960e3778", null ],
    [ "USE_NEW_LOG2", "compatible_8h.html#a7a9986d204e2f0828e70bf3f6f18aaa0", null ],
    [ "USE_NEW_SCANF_S", "compatible_8h.html#a7551b0fd4c9ec281462b9b8ed2b8aff1", null ],
    [ "USE_NEW_SPRINTF_S", "compatible_8h.html#a632556f92690175f24812028e367d4d9", null ],
    [ "USE_NEW_SSCANF_S", "compatible_8h.html#a092c9ee59777034b4fbdf99d16ed4015", null ]
];