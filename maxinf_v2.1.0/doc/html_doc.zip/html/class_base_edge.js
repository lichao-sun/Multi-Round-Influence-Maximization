var class_base_edge =
[
    [ "BaseEdge", "class_base_edge.html#ab8ded7f86ac7ba8244716c15a5400343", null ],
    [ "u", "class_base_edge.html#a1d01bfce193b918ae71895648f1db4a8", null ],
    [ "v", "class_base_edge.html#ac38284a3d5042e10f8ac9abd121fa6bd", null ]
];