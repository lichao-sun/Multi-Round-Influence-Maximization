var dir_050edd66366d13764f98250ef6db77f6 =
[
    [ "cascade.cpp", "cascade_8cpp.html", null ],
    [ "cascade.h", "cascade_8h.html", [
      [ "ICascade", "class_i_cascade.html", "class_i_cascade" ],
      [ "CascadeT", "class_cascade_t.html", "class_cascade_t" ]
    ] ],
    [ "cgreedy.cpp", "cgreedy_8cpp.html", null ],
    [ "cgreedy.h", "cgreedy_8h.html", [
      [ "CGreedy", "class_c_greedy.html", "class_c_greedy" ]
    ] ],
    [ "common.cpp", "common_8cpp.html", "common_8cpp" ],
    [ "common.h", "common_8h.html", "common_8h" ],
    [ "compatible.cpp", "compatible_8cpp.html", null ],
    [ "compatible.h", "compatible_8h.html", "compatible_8h" ],
    [ "contcascade.cpp", "contcascade_8cpp.html", null ],
    [ "contcascade.h", "contcascade_8h.html", [
      [ "TimeItem", "class_time_item.html", "class_time_item" ],
      [ "ContGeneralCascade", "class_cont_general_cascade.html", "class_cont_general_cascade" ]
    ] ],
    [ "degree.cpp", "degree_8cpp.html", null ],
    [ "degree.h", "degree_8h.html", [
      [ "Degree", "class_degree.html", "class_degree" ]
    ] ],
    [ "degreediscount_ic.cpp", "degreediscount__ic_8cpp.html", null ],
    [ "degreediscount_ic.h", "degreediscount__ic_8h.html", [
      [ "DegreeDiscount_IC", "class_degree_discount___i_c.html", "class_degree_discount___i_c" ]
    ] ],
    [ "event_timer.cpp", "event__timer_8cpp.html", null ],
    [ "event_timer.h", "event__timer_8h.html", "event__timer_8h" ],
    [ "general_cascade.cpp", "general__cascade_8cpp.html", null ],
    [ "general_cascade.h", "general__cascade_8h.html", "general__cascade_8h" ],
    [ "graph.cpp", "graph_8cpp.html", null ],
    [ "graph.h", "graph_8h.html", "graph_8h" ],
    [ "graph_stat.cpp", "graph__stat_8cpp.html", null ],
    [ "graph_stat.h", "graph__stat_8h.html", "graph__stat_8h" ],
    [ "greedy.cpp", "greedy_8cpp.html", null ],
    [ "greedy.h", "greedy_8h.html", [
      [ "Greedy", "class_greedy.html", "class_greedy" ]
    ] ],
    [ "greedy_online.cpp", "greedy__online_8cpp.html", null ],
    [ "greedy_online.h", "greedy__online_8h.html", [
      [ "GreedyOnline", "class_greedy_online.html", "class_greedy_online" ]
    ] ],
    [ "independ_cascade.cpp", "independ__cascade_8cpp.html", null ],
    [ "independ_cascade.h", "independ__cascade_8h.html", [
      [ "IndependCascade", "class_independ_cascade.html", "class_independ_cascade" ]
    ] ],
    [ "limit.h", "limit_8h.html", "limit_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mi_command_line.cpp", "mi__command__line_8cpp.html", null ],
    [ "mi_command_line.h", "mi__command__line_8h.html", [
      [ "MICommandLine", "class_m_i_command_line.html", "class_m_i_command_line" ]
    ] ],
    [ "mi_random.cpp", "mi__random_8cpp.html", null ],
    [ "mi_random.h", "mi__random_8h.html", [
      [ "MIRandom", "class_m_i_random.html", "class_m_i_random" ],
      [ "ProbConverter", "class_prob_converter.html", null ]
    ] ],
    [ "mi_util.cpp", "mi__util_8cpp.html", null ],
    [ "mi_util.h", "mi__util_8h.html", "mi__util_8h" ],
    [ "mia.cpp", "mia_8cpp.html", null ],
    [ "mia.h", "mia_8h.html", [
      [ "MIA", "class_m_i_a.html", "class_m_i_a" ]
    ] ],
    [ "mis.cpp", "mis_8cpp.html", null ],
    [ "mis.h", "mis_8h.html", [
      [ "MIS", "class_m_i_s.html", "class_m_i_s" ]
    ] ],
    [ "pagerank.cpp", "pagerank_8cpp.html", null ],
    [ "pagerank.h", "pagerank_8h.html", [
      [ "Pagerank", "class_pagerank.html", "class_pagerank" ]
    ] ],
    [ "pmia.cpp", "pmia_8cpp.html", "pmia_8cpp" ],
    [ "pmia.h", "pmia_8h.html", [
      [ "PMIA", "class_p_m_i_a.html", "class_p_m_i_a" ]
    ] ],
    [ "random_pick.cpp", "random__pick_8cpp.html", null ],
    [ "random_pick.h", "random__pick_8h.html", [
      [ "RandomPick", "class_random_pick.html", "class_random_pick" ]
    ] ],
    [ "reverse_general_cascade.cpp", "reverse__general__cascade_8cpp.html", null ],
    [ "reverse_general_cascade.h", "reverse__general__cascade_8h.html", "reverse__general__cascade_8h" ],
    [ "rr_infl.cpp", "rr__infl_8cpp.html", [
      [ "CountComparator", "struct_count_comparator.html", "struct_count_comparator" ]
    ] ],
    [ "rr_infl.h", "rr__infl_8h.html", [
      [ "RRInflBase", "class_r_r_infl_base.html", "class_r_r_infl_base" ],
      [ "RRInfl", "class_r_r_infl.html", "class_r_r_infl" ],
      [ "TimPlus", "class_tim_plus.html", "class_tim_plus" ],
      [ "IMM", "class_i_m_m.html", "class_i_m_m" ]
    ] ],
    [ "simulate.cpp", "simulate_8cpp.html", null ],
    [ "simulate.h", "simulate_8h.html", [
      [ "Simu", "class_simu.html", "class_simu" ]
    ] ],
    [ "SP1M_gc.cpp", "_s_p1_m__gc_8cpp.html", null ],
    [ "SP1M_gc.h", "_s_p1_m__gc_8h.html", [
      [ "SP1M_gc", "class_s_p1_m__gc.html", "class_s_p1_m__gc" ]
    ] ],
    [ "SPM_gc.cpp", "_s_p_m__gc_8cpp.html", null ],
    [ "SPM_gc.h", "_s_p_m__gc_8h.html", [
      [ "SPM_gc", "class_s_p_m__gc.html", "class_s_p_m__gc" ]
    ] ],
    [ "top_selection.cpp", "top__selection_8cpp.html", null ],
    [ "top_selection.h", "top__selection_8h.html", [
      [ "TopSelection", "class_top_selection.html", "class_top_selection" ]
    ] ],
    [ "topic_aware.cpp", "topic__aware_8cpp.html", null ],
    [ "topic_aware.h", "topic__aware_8h.html", [
      [ "MINode", "struct_m_i_node.html", "struct_m_i_node" ],
      [ "TASeeds", "struct_t_a_seeds.html", "struct_t_a_seeds" ],
      [ "TopicAwareBase", "class_topic_aware_base.html", "class_topic_aware_base" ]
    ] ],
    [ "weighted_degree.cpp", "weighted__degree_8cpp.html", null ],
    [ "weighted_degree.h", "weighted__degree_8h.html", [
      [ "WeightedDegree", "class_weighted_degree.html", "class_weighted_degree" ]
    ] ]
];