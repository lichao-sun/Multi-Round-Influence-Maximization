var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvw~",
  1: "_bcdefgimnprstw",
  2: "cdegilmprstw",
  3: "_abcdefghilmnoprstw~",
  4: "abcdefghiklmnopqrstuvw",
  5: "_bcdegkprstuvw",
  6: "ims",
  7: "cdefglmnsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerator",
  7: "Macros"
};

