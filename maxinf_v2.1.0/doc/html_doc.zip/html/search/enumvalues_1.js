var searchData=
[
  ['majorver',['MajorVer',['../class_m_i_common.html#a091337858587e68a6c2c78c3b815fbaaa0edbeb1a97c3d25b0aa08c484d2a35f7',1,'MICommon']]]
];
