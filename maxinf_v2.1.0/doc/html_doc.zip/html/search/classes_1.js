var searchData=
[
  ['baseedge',['BaseEdge',['../class_base_edge.html',1,'']]]
];
