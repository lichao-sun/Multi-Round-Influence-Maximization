var searchData=
[
  ['applytransform',['ApplyTransform',['../class___edge_downward_adapter.html#ad5224d712ae9eb7b76a2cf913ab0155a',1,'_EdgeDownwardAdapter']]]
];
