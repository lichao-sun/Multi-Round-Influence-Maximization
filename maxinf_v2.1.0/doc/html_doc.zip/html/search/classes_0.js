var searchData=
[
  ['_5fedgedownwardadapter',['_EdgeDownwardAdapter',['../class___edge_downward_adapter.html',1,'']]]
];
