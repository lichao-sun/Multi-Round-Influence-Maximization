var searchData=
[
  ['_5faddrrsimulation',['_AddRRSimulation',['../class_r_r_infl_base.html#acc9af715f006a40529b62ee1fc458ea8',1,'RRInflBase::_AddRRSimulation(size_t num_iter, cascade_type &amp;cascade, std::vector&lt; RRVec &gt; &amp;refTable, std::vector&lt; int &gt; &amp;refTargets)'],['../class_r_r_infl_base.html#acb5d01666cc9fa04f8da60fc2431b3d7',1,'RRInflBase::_AddRRSimulation(size_t num_iter, cascade_type &amp;cascade, std::vector&lt; RRVec &gt; &amp;refTable, std::vector&lt; int &gt; &amp;refTargets, std::vector&lt; int &gt; &amp;refEdgeVisited)']]],
  ['_5fbuild',['_Build',['../class_cascade_t.html#ab8538e0b94f0ddf5813b18da0f757532',1,'CascadeT::_Build()'],['../class_r_r_infl.html#a2aca855b2dea36762bf5282b6e34946b',1,'RRInfl::_Build()']]],
  ['_5festimateinfl',['_EstimateInfl',['../class_r_r_infl_base.html#abd1bb7a2b72c1b4c5490ddf56167dc69',1,'RRInflBase']]],
  ['_5fqsort',['_qsort',['../class_edge_sorter_t.html#a4c82aad391170b55e0956021b6bb0929',1,'EdgeSorterT']]],
  ['_5frebuildrrindices',['_RebuildRRIndices',['../class_r_r_infl_base.html#a7cc21895a62d0dca85a21ca2832b9324',1,'RRInflBase']]],
  ['_5frungreedy',['_RunGreedy',['../class_r_r_infl_base.html#a09819aaa89723c1d66aec5a28bc71ace',1,'RRInflBase']]],
  ['_5fsetresults',['_SetResults',['../class_r_r_infl_base.html#a426dc2f24d689df213d8bb16de432421',1,'RRInflBase']]]
];
