var searchData=
[
  ['gen_5fhas_5fmem',['GEN_HAS_MEM',['../mi__util_8h.html#aaa6c53130644175366bb2d1ca1e63762',1,'mi_util.h']]],
  ['gen_5fhas_5fmem_5ftype',['GEN_HAS_MEM_TYPE',['../mi__util_8h.html#a1a9406c4e9cb21ec30e9444d52227c92',1,'mi_util.h']]]
];
