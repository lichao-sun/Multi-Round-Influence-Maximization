var searchData=
[
  ['safe_5fdelete',['SAFE_DELETE',['../common_8h.html#ad45c5447fa213228e8493458c1770e91',1,'common.h']]],
  ['safe_5fdelete_5farray',['SAFE_DELETE_ARRAY',['../common_8h.html#a7541454697b30d05714aa6b2150500b1',1,'common.h']]],
  ['scanf_5fs',['scanf_s',['../compatible_8h.html#a4435ae4ec4f90d537406f802968b254c',1,'compatible.h']]],
  ['set_5fsize',['SET_SIZE',['../limit_8h.html#aa6e05f1d2f795fe52b3a112b050db5ea',1,'limit.h']]],
  ['sprintf_5fs',['sprintf_s',['../compatible_8h.html#a6b6019110450b61a0b4acc55d7d336ca',1,'compatible.h']]],
  ['sscanf_5fs',['sscanf_s',['../compatible_8h.html#a6730fd34a693bf06bb129ee0166c66f6',1,'compatible.h']]],
  ['str_5flen',['STR_LEN',['../limit_8h.html#af5b27449abdfc22a937250696492e03f',1,'limit.h']]]
];
