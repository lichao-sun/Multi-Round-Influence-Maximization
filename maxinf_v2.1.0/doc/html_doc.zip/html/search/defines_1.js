var searchData=
[
  ['defget',['DefGet',['../common_8h.html#ab98391c9d0088f199e95e217e894f428',1,'common.h']]],
  ['defgetset',['DefGetSet',['../common_8h.html#ae4f8d621015955eea81fb7458b91920d',1,'common.h']]],
  ['defset',['DefSet',['../common_8h.html#a019c80b1ad0dc1d1e367334fa3ef9855',1,'common.h']]]
];
