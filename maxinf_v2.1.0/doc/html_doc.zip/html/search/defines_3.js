var searchData=
[
  ['fopen_5fs',['fopen_s',['../compatible_8h.html#a68aa08b41214e531d230855fbc807d75',1,'compatible.h']]],
  ['fscanf_5fs',['fscanf_s',['../compatible_8h.html#a0a33c9047aaa39206cb522b2b9900bbb',1,'compatible.h']]]
];
