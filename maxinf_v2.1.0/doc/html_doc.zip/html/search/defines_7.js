var searchData=
[
  ['ns_5ffutures_5fbegin',['NS_FUTURES_BEGIN',['../common_8h.html#a957ca674986b5eb5581e8189d3b40062',1,'common.h']]],
  ['ns_5ffutures_5fend',['NS_FUTURES_END',['../common_8h.html#a36492afbf2ff96843d426bead2074626',1,'common.h']]],
  ['ns_5fmi_5fbegin',['NS_MI_BEGIN',['../common_8h.html#a92ede37b996062614f14f902633c0137',1,'common.h']]],
  ['ns_5fmi_5fend',['NS_MI_END',['../common_8h.html#a170cd5c79b2a926f9f4781c093d7effb',1,'common.h']]],
  ['ns_5fuse_5ffutures',['NS_USE_FUTURES',['../common_8h.html#a5c89b63a13282f3c9c45618493b5a9ac',1,'common.h']]],
  ['ns_5fuse_5fmi',['NS_USE_MI',['../common_8h.html#a78f5c350706b6f97afd30b319454b62a',1,'common.h']]],
  ['num_5fiter',['NUM_ITER',['../limit_8h.html#a54141d8b6f8555b5e7998203c65e81da',1,'limit.h']]]
];
