var searchData=
[
  ['lambdaprime',['LambdaPrime',['../class_i_m_m.html#ad9e889d2cc9ee23112ae16de668d8a3a',1,'IMM']]],
  ['lambdastar',['LambdaStar',['../class_i_m_m.html#a93b218446baadb630c064a99fc35fc05',1,'IMM']]],
  ['large_5fint64',['LARGE_INT64',['../common_8h.html#a46ed39af5ed6a3eeab8bcc90f3cc0d44',1,'common.h']]],
  ['largepair',['largepair',['../pmia_8cpp.html#a965cabd7800215d08ac4989c69e733b4',1,'pmia.cpp']]],
  ['lastupdate',['lastupdate',['../class_p_m_i_a.html#a8b58ce2ff60f7912d4fa47904448cb20',1,'PMIA']]],
  ['limit_2eh',['limit.h',['../limit_8h.html',1,'']]],
  ['list',['list',['../class_greedy.html#a0517f163a334ef64cc153ba0c757e8a9',1,'Greedy::list()'],['../class_greedy_online.html#a08313f139e78edaa841360e9398dfbd1',1,'GreedyOnline::list()'],['../class_p_m_i_a.html#ab2f993e51a4126e82f76e02ef1dbfb02',1,'PMIA::list()'],['../class_r_r_infl_base.html#a34bd9f6f34257892878d1721dbc51497',1,'RRInflBase::list()']]],
  ['log2',['log2',['../compatible_8h.html#a18af743c2cec4baeee9ffb27999ddaad',1,'compatible.h']]],
  ['lognchoosek',['LogNChooseK',['../class_tim_plus.html#a0f281fcccd212e610ae90ecfc9ed7573',1,'TimPlus']]],
  ['logstar',['logStar',['../class___edge_downward_adapter.html#a0e1eb68a15a7981629232e9c1993a7c0',1,'_EdgeDownwardAdapter']]],
  ['longest',['longest',['../class_p_m_i_a.html#a50297a1484b205a868e3b411bcee4027',1,'PMIA']]]
];
