var searchData=
[
  ['use_5fnew_5ffopen_5fs',['USE_NEW_FOPEN_S',['../compatible_8h.html#aeef76583b5f1f427735e4320838b1c3f',1,'compatible.h']]],
  ['use_5fnew_5ffscanf_5fs',['USE_NEW_FSCANF_S',['../compatible_8h.html#a90dd1fcfe2cee5eb0812c167960e3778',1,'compatible.h']]],
  ['use_5fnew_5flog2',['USE_NEW_LOG2',['../compatible_8h.html#a7a9986d204e2f0828e70bf3f6f18aaa0',1,'compatible.h']]],
  ['use_5fnew_5fscanf_5fs',['USE_NEW_SCANF_S',['../compatible_8h.html#a7551b0fd4c9ec281462b9b8ed2b8aff1',1,'compatible.h']]],
  ['use_5fnew_5fsprintf_5fs',['USE_NEW_SPRINTF_S',['../compatible_8h.html#a632556f92690175f24812028e367d4d9',1,'compatible.h']]],
  ['use_5fnew_5fsscanf_5fs',['USE_NEW_SSCANF_S',['../compatible_8h.html#a092c9ee59777034b4fbdf99d16ed4015',1,'compatible.h']]]
];
