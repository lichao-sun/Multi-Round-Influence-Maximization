var class_cont_edge =
[
    [ "ContEdge", "class_cont_edge.html#a33848ec898b136ccb5d99886acd32991", null ],
    [ "Deserialize", "class_cont_edge.html#a8231e7f8fee45059c1048b417e740f96", null ],
    [ "Serialize", "class_cont_edge.html#aed6758a143942674eae885b7cecb4b0d", null ],
    [ "u_a", "class_cont_edge.html#afec7b8d953b3d39969f49a0e3101a743", null ],
    [ "u_b", "class_cont_edge.html#aac576c9e465f6a08905df8c50dc8e317", null ],
    [ "v_a", "class_cont_edge.html#a29c5ce3fe287828cc26113e8dd00ca80", null ],
    [ "v_b", "class_cont_edge.html#ade9e08990dcde3bed5f1ab9d85038a8b", null ]
];