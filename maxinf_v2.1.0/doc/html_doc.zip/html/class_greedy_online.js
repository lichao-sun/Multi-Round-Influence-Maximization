var class_greedy_online =
[
    [ "GreedyOnline", "class_greedy_online.html#a2aaef5e9426573c40f206ad61fafff38", null ],
    [ "Build", "class_greedy_online.html#a55822badc11a5b5d3029653dc373b462", null ],
    [ "BuildFromFile", "class_greedy_online.html#a1e4d000599a99180518243ba01c8ace1", null ],
    [ "BuildRanking", "class_greedy_online.html#a8a51d20b6b561a7ecb88a2043fd6476c", null ],
    [ "GetSeed", "class_greedy_online.html#aade0a076c5a4b278dfadc613d95eaa13", null ],
    [ "GetSeedList", "class_greedy_online.html#a93f8de5993e67ec4acd7f034d1d2cbab", null ],
    [ "SortBestToTop", "class_greedy_online.html#a1c0a2416db46286cb167edb7973a53c1", null ],
    [ "d", "class_greedy_online.html#a2bf3a16c5d32b65041b79b8d14886e11", null ],
    [ "file", "class_greedy_online.html#a670bd20711c6df1e8a70f0bc14a4a250", null ],
    [ "isOnlineEstimated", "class_greedy_online.html#ae0841b19af14d0ec2031a14426a87d44", null ],
    [ "list", "class_greedy_online.html#a08313f139e78edaa841360e9398dfbd1", null ],
    [ "n", "class_greedy_online.html#ae9912db9632d8bccd18b72a906125c1e", null ],
    [ "onlinebound_file", "class_greedy_online.html#a0f3bf5b34605cba3a839845cb58ad552", null ],
    [ "onlineD", "class_greedy_online.html#ad6d9e3e88dad733f72c6744262b493cd", null ],
    [ "onlineSeeds", "class_greedy_online.html#a83e161aa189873b481d8b1e5a25ef7e5", null ],
    [ "top", "class_greedy_online.html#afe20323ab01b6079fbcb36691852f02c", null ]
];